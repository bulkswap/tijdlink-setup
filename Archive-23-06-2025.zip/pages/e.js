
export default function Expired() {
  if (typeof window !== "undefined") {
    window.location.href = "https://beltegoed.nl/bol-com-cadeaukaart";
  }
  return null;
}
