
export default function Home() {
  return <h1>Welkom bij Tijdlink</h1>;
}
